package ims.app;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

public class InventoryManager extends Person {
    /**
     *
     */
    private Warehouse items;

    /**
     *
     * @param firstName
     * @param lastName
     * @param username
     * @param password
     * @param role
     */
    public InventoryManager(String firstName, String lastName, String username, String password, String role) {
        super(firstName, lastName, username, password, role);
    }

//    /**
//     *
//     * @param p
//     * @throws Exception
//     */
//    public void addProduct(Product p) throws Exception { items.addItem(p); }

    /**
     *
     * @param p
     * @return
     * @throws Exception
     */
    public Product viewProduct(Product p) throws Exception {
        String filePath = new File("").getAbsolutePath() + "/app/src/main/java/ims/app/inventory.txt";
        File file = new File(filePath);

        FileReader fr = new FileReader(file);
        BufferedReader br = new BufferedReader(fr);

        Object[] lines = br.lines().toArray();

        for (Object line : lines) {
            String row = line.toString();
            if (row.equals(p.toString())) return p;
        }

        throw new Exception("Product not found.");
    }

//    /**
//     *
//     * @param p
//     * @throws Exception
//     */
//    public void removeProduct(Product p) throws Exception { items.removeItem(p); }

    /**
     *
     * @return
     */
    public String getUsername() { return username; }

    /**
     *
     * @param uname
     */
    public void setUsername(String uname) { username = uname; }

    /**
     *
     * @return
     */
    public String getPassword() { return password; }

    /**
     *
     * @param pword
     */
    public void setPassword(String pword) { password = pword; }

    /**
     *
     * @param args
     */
    public static void main(String[] args) throws Exception {

    }
}
