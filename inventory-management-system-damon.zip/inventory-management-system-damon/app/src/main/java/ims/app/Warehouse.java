package ims.app;

import java.io.*;

public class Warehouse {

    private static Warehouse warehouse_instance = null;

    private int capacity = 99;
    private String name = "My Warehouse";

    private Warehouse() {

    }

    public static Warehouse getInstance() {
        if (warehouse_instance == null) {
            warehouse_instance = new Warehouse();
        }
        return warehouse_instance;
    }


    /**
     * @return
     */
    public String getName() { return this.name; }

    /**
     * @return
     */
    public int getCapacity() { return this.capacity; }

    /**
     * @param name
     */
    public void setName(String name) { this.name = name; }

    public int getCount() {

        int count = 0;
        String filePath = new File("").getAbsolutePath() + "/src/main/resources/inventory/inventory.txt";

        try {
            BufferedReader reader = new BufferedReader(new FileReader(filePath));
            while (reader.readLine() != null) {
                count++;
            }
        }
        catch (Exception e) {
            System.out.println(e);
        }

        return count;
    }

    /**
     * @param p
     */
    public void addItems(Product p) throws Exception {
        if (getCount() >= capacity) throw new Exception("Warehouse is full.");

        String filePath = new File("").getAbsolutePath() + "/src/main/resources/inventory/inventory.txt";
        File file = new File(filePath);

        try {
            FileWriter fw = new FileWriter(file, true);
            BufferedWriter bw = new BufferedWriter(fw);

            bw.write(p.toString());
            bw.write("\n");

            bw.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    /**
     * @param p
     */
    public void removeItems(Product p) throws Exception {
        if (this.getCount() == 0) throw new Exception("Cannot remove items from an empty warehouse.");

        String filePath = new File("").getAbsolutePath() + "/src/main/resources/inventory/inventory.txt";
        File file = new File(filePath);

        try {
            FileWriter fw = new FileWriter(file, true);
            BufferedWriter bw = new BufferedWriter(fw);

            FileReader fr = new FileReader(file);
            BufferedReader br = new BufferedReader(fr);

            Object[] lines = br.lines().toArray();

            fw = new FileWriter(file, false);
            bw = new BufferedWriter(fw);

            for (Object line : lines) {
                if (!line.toString().equals(p.toString())) {
                    bw.write(line.toString());
                    bw.write("\n");
                }
            }
            bw.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    /**
     *
     * @param args
     * @throws Exception
     */
    public static void main(String[] args) throws Exception {
        Warehouse w = Warehouse.getInstance();
        Product p = new Product("10", "LG", "Electronics", "Bay 1", 1, 1000.22, "damon");

        // Testing getters
        System.out.println(w.getName());
        System.out.println(w.getCapacity());
        System.out.println(w.getCount());

        // Testing setters
        w.addItems(p);
        System.out.println(w.getCount());
        w.removeItems(p);
        System.out.println(w.getCount());

    }
}

