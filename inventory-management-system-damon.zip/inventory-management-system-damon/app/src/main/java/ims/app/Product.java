package ims.app;

public class Product {
    protected String productID, productName, productLocation, productCategory, productOwner;
    protected double productPrice;
    protected int productQuantity;
    

    public Product(String ID, String name, String category, String location, int quantity, double price, String owner) {
        this.productID = ID;
        this.productName = name;
        this.productCategory = category;
        this.productLocation = location;
        this.productQuantity = quantity;
        this.productPrice = price;
        this.productOwner = owner;
        
    }

    public String getProductID() { return productID; }

    public String getProductName() { return productName; }

    public String getProductCategory() { return productCategory; }

    public String getProductLocation() { return productLocation; }

    public double getProductPrice() { return productPrice; }

    public int getProductQuantity() { return productQuantity; }
    
    public String getProductOwner() {return productOwner; }



    public void displayDetails() {
        System.out.println("ProductID: " + getProductID() + "\n");
        System.out.println("ProductName: " + getProductName() + "\n");
        System.out.println("ProductCategory: " + getProductCategory() + "\n");
        System.out.println("ProductLocation: " + getProductLocation() + "\n");
        System.out.println("Quantity: " + getProductQuantity() + "\n");
        System.out.println("Price: " + getProductPrice() + "\n");
    }

    public String toString() {
        return getProductID() + ", " + getProductName() + ", " + getProductCategory() + ", " + getProductLocation() + ", " + getProductQuantity() + ", " + getProductPrice() + ", " + getProductOwner();
    }

    public static void main(String[] args) {
        System.out.println("Testing Product");
        Product p = new Product("1", "product1", "category1", "Bay 1", 12, 12.11, "damon");
        p.displayDetails();
        System.out.println(p.toString());
    }
}

