package ims.app;

public class GeneralManager extends Person {
    /**
     * GeneralManager's username and password fields
     */
    private String username, password;

    /**
     * Create an instance of GeneralManager
     * @param firstName
     * @param lastName
     * @param username
     * @param password
     * @param role
     */
    public GeneralManager(String firstName, String lastName, String username, String password, String role) {
        super(firstName, lastName, username, password, role);
    }

    /**
     * Display the General Manager page
     */
    public void getInventoryReport() {
        Main main = new Main("General Manager");
        main.setVisible(true);
    }

    /**
     * @return the GeneralManager's password
     */
    public String getPassword() { return password; }

    /**
     * @return the GeneralManager's username
     */
    public String getUsername() { return username; }

    /**
     * Sets a new password for GeneralManager
     *
     * @param new_password username to set
     */
    public void setPassword(String new_password) { password = new_password; }

    /**
     * Sets a new username for GeneralManager
     *
     * @param new_username username to set
     */
    public void setUsername(String new_username) { username = new_username; }

    /**
     * Main method for testing
     *
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        GeneralManager George = new GeneralManager("George", "Clooney", "username", "password", "General Manager");

        // test getPassword()
        if (George.getPassword() != null)
            System.out.println("getPassword() should've returned null, but returned " + George.getPassword() + "instead");

        // test setPassword()
        George.setPassword("password");
        if (George.getPassword() == null)
            System.out.println("Password is not null");
        if (!George.getPassword().equals("password"))
            System.out.println("getPassword() should have returned 'password', but instead returned " + George.getPassword());

        // test getUsername
        if (George.getUsername() != null)
            System.out.println("getUsername() should've returned null, but returned " + George.getUsername() + " instead.");

        // test setUsername()
        George.setUsername("g.clooney");
        if (George.getUsername() == null)
            System.out.println("Username is not null");
        if (!George.getUsername().equals("g.clooney"))
            System.out.println("getPassword() should have returned 'g.clooney', but instead returned " + George.getPassword());

        // test setPassword() again
        George.setPassword("12345");
        if (George.getPassword().equals("password"))
            System.out.println("Password is no longer 'password'.");
        if (George.getPassword() == null)
            System.out.println("Password is not null");
        if (!George.getPassword().equals("12345"))
            System.out.println("getPassword() should have returned '12345', but instead returned " + George.getPassword());

        // test setUsername() again
        George.setUsername("george_clooney");
        if (George.getUsername().equals("g.clooney"))
            System.out.println("Username is no longer 'g.clooney'.");
        if (George.getUsername() == null)
            System.out.println("Username is not null.");
        if (!George.getUsername().equals("george_clooney"))
            System.out.println("getPassword() should have returned 'g.clooney', but instead returned " + George.getPassword());

        // test getInventoryReport()
        try {
            George.getInventoryReport();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        System.out.println("End of regression test.");
    }
}
