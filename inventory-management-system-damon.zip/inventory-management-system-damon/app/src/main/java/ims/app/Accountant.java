package ims.app;

import javax.swing.*;
import java.io.*;
import java.util.*;

public class Accountant extends Person {
    /**
     *
     */
    private String firstname, lastname, username, password, role;

    /**
     *
     */
    private String period, revenue, cogs, grossProfit, grossMargin, operatingExpenses, netIncome;

    /**
     *
     * @param firstName
     * @param lastName
     */
    public Accountant(String firstName, String lastName, String username, String password, String role) {
        super(firstName, lastName, username, password, role);
    }

    /**
     * Generate a new financial statement
     * (Thinking about moving most of reportGeneratedActionPerformed from Main.java to here)
     *
     * @param period
     * @param revenue
     * @param cogs
     * @param operatingExpenses
     */
    public void generateStatement(String period, double revenue, double cogs, double operatingExpenses) {
        String fileName;

        FinancialStatement fs = new FinancialStatement(period, revenue, cogs, operatingExpenses);

        // period: mmm-dd-yyyy -> List(mmm, dd, yyyy)
        String[] periodBreakdown = period.split("-");

        // period Structure: dayOfAWeek Month Day time timeZone year
        fileName = periodBreakdown[0] + "_" + periodBreakdown[1] + "_" + periodBreakdown[2] + ".txt";

        try {
            File file = new File(new File("").getAbsolutePath() + "/src/main/resources/reports/" + fileName);
            FileWriter fw = new FileWriter(file);
            // write into the file
            try (PrintWriter pw = new PrintWriter(fw)) {
                // write into the file
                pw.write(fs.generateReport());
                JOptionPane.showMessageDialog(null, "Report Generated Successfully!");
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    /**
     *
     */
    public void viewStatements() {
        Main m = new Main("Accountant");
        m.setVisible(true);
    }

    public static void main(String[] args) {
        Accountant JeanLuc = new Accountant("Jean-Luc", "Picard", "starship", "enterprise", "Accountant");
//        JeanLuc.generateStatement("Apr-05-2021", 123123.0, 1.0, 12122.0);
        JeanLuc.viewStatements();
    }
}
