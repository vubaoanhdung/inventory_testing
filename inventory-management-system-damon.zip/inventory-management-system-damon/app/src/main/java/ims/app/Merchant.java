package ims.app;

import java.io.*;

public class Merchant extends Person {

    /**
     *
     */
    protected String username;

    /**
     *
     */
    protected String password;

    /**
     *
     * @param firstName
     * @param lastName
     * @param username
     * @param password
     * @param role
     */
    public Merchant(String firstName, String lastName, String username, String password, String role) {
        super(firstName, lastName, username, password, role);
    }

    /**
     *
     */
    public void getMyItems() {
        String filePath = new File("").getAbsolutePath() + "/src/main/resources/inventory/inventory.txt";
        File file = new File(filePath);

        try {
            FileReader fr = new FileReader(file);
            BufferedReader br = new BufferedReader(fr);
            Object[] lines = br.lines().toArray();

            for (Object line : lines) {
                String row = line.toString();
                if (row.contains(this.getFirstName())) System.out.println(row);
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

//    /**
//     * @param itemsDetail
//     */
//    public void itemsDetails(String itemsDetail) {
//        String filePath = new File("").getAbsolutePath() + "/src/main/resources/inventory/inventory.txt";
//        File file = new File(filePath);
//
//        try {
//            FileReader fr = new FileReader(file);
//            BufferedReader br = new BufferedReader(fr);
//            Object[] lines = br.lines().toArray();
//
//            for (Object line : lines) {
//                String row = line.toString();
//                if (row.contains(itemsDetail)) System.out.println(row);
//            }
//        } catch (Exception e) {
//            System.out.println(e.getMessage());
//        }
//    }

    public String getUsername() {
        return this.username;
    }

    public void setUsername(String uname) {
        this.username = uname;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String pword) {
        this.password = pword;
    }

    public static void main(String[] args) {
        //test part
        Merchant Mike = new Merchant("Damon", "lalala", "warhouse", "1000", "100");
//        Mike.setUsername("blablabla");
//        if (!Mike.getUsername().equals("blablabla")) {
//            System.out.println("the setUsername is failed");
//        }
//
//        System.out.println(Mike.getPassword());
//        Mike.setPassword("blablabla");
//        if (!Mike.getPassword().equals("blablabla")) {
//            System.out.println("the setPassward is failed");
//        }

        Mike.getMyItems();

        System.out.println("text done");
    }

}
