package ims.app;

public class Person {
    public String firstName, lastName, username, password, role;

    public Person(String firstname, String lastname, String username, String password, String role) {
        this.firstName = firstname;
        this.lastName = lastname;
        this.username = username;
        this.password = password;
        this.role = role;

    }

    public String getPassword() {
        return this.password;
    }

    public String getUsername() {
        return this.username;
    }

    public String getFirstName() {
        return this.firstName;
    }

    public String getLastName() {
        return this.lastName;
    }

    public String getRole() {
        return this.role;
    }

    public String toString() {
        return this.getUsername() + ", " + this.getPassword() + ", " + this.getRole();
    }

    public void setPassword(String new_password) {
        password = new_password;
    }

    public void setUsername(String new_username) {
        username = new_username;
    }
}
