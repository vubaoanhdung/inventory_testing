package ims.app;

import java.text.DecimalFormat;

public class FinancialStatement {
    private String period;
    private double revenue;
    private double cogs;
    private double operatingExpenses;
    private DecimalFormat df = new DecimalFormat("#.##");

    public FinancialStatement(String period, double revenue, double cogs, double operatingExpenses) {
        
        this.period = period;
        this.revenue = formatNumber(revenue);
        this.cogs = formatNumber(cogs);
        this.operatingExpenses = formatNumber(operatingExpenses);
    }

    private double calculateGrossProfit() {
        double grossProfit = this.revenue - this.cogs;
        return formatNumber(grossProfit);
    }

    private double calculateGrossMargin() {
        double grossMargin = calculateGrossProfit()/this.revenue;
        return formatNumber(grossMargin);
    }

    private double calculateNetIncome() {
        double netIncome = this.revenue - this.cogs - this.operatingExpenses;
        return formatNumber(netIncome);
    }
    
    // function help to format a double number 
    // into a form of: #.##
    private double formatNumber(double d) {
        return Double.valueOf(df.format(d));
    }

    public String generateReport() {
        return "Period: " + this.period + "\nRevenue: " + this.revenue + "\nCost of Good Sold: " + this.cogs +
                "\nGross Profit: " + this.calculateGrossProfit() + "\nGross Margin: " + this.calculateGrossMargin() + "\nOperating Expenses: " + this.operatingExpenses + "\nNet Income: " + this.calculateNetIncome();
    }

    public static void main(String[] args) {
        FinancialStatement r = new FinancialStatement("mar-10-2021", 100.00,20.00,23);
        System.out.println(r.generateReport());
    }
}
